﻿# AWA Visio(n) 1.0 / 07.07.2016
# Converts CSV export to Visio.

# Code, stencils and basic SQLs by Joel Wiesmann / joel.wiesmann@gmail.com
# Requires: Visio 2010 or 2016. Might work with earlier versions as well. Only professional has been tested. I'll add some more comments in the next version. I promise.

#################################################################################################################################################################
# Parameters
#################################################################################################################################################################
# -csvTaskDataFile <file.csv>   -- CSV file to use for task data
# -csvRelDataFile <file.csv>    -- CSV file to use for task relations
# -outputFile <output.vsd>  -- All visio export formats supported! If the file is VSD and the page name does not yet exist in the document, 
#                              a new tab is created, else the existing page is being replaced.
# [-xSpacing <number>]      -- Increase multiplier to increase spacing on x axis
# [-ySpacing <number>]      -- Increase multiplier to increase spacing on y axis
# [-pagename "Pagename"]    -- Name of the page that is being created. By default "AWA Visio(n)".
# [-stencilFile <stencil.vss>]  -- Stencil file to use. If no stencil is defined, .\data\default.vss will be used.
# [-visioVisible]           -- Visio will be visible when the workflow is being built. Default is "no".
# [-delimiter <;>]          -- Change delimiter used for CSV parsing. If no delimiter is being given, "," will be used (default by sqlQuery.ps1).
#################################################################################################################################################################

Param(
    [Parameter(Mandatory=$True)][string]$csvTaskDataFile,
    [Parameter(Mandatory=$True)][string]$csvRelDataFile,
    [Parameter(Mandatory=$True)][string]$outputFile,
    [float]$xSpacing = 3,
    [float]$ySpacing = 2,
    [string]$pageName = "AWA Visio(n)",
    [string]$stencilFile = ".\data\default.vss",
    [string]$delimiter = ";",
    [boolean]$visioVisible = $False
)

$files = @{}

#################################################################################################################################################################
# Functions
#################################################################################################################################################################
# Verify if all files are there and relative paths can be resolved properly. Register all files in the $files hash array.
function validateDatafileAvailability($file) {
    if (! ($resolvedPath = Resolve-Path($file))) {
        write-host ("! Could not resolve path to " + $file)
        exit 1
    }
    $resolvedPath
}

# Helper function to validate the availability of MUST fields within CSV file
function checkMandatoryField($field, $file, $checkData) {
    if (! [bool]($checkData.psobject.properties | where { $_.Name -eq $field })) {
        write-host "! Missing field $field in $file"
        exit 1
    }
}

# This function assignes data to shapes. To do so we have to identify the available fields and then verify whether our
# CSV data record contains a field that matches the name of the shapedata.
function assignDataToShape($taskData, $shape) {
    # Does the shape have any data fields?
    try { $dataFieldCount = $shape.rowcount(243) }
    catch { return }

    if ($dataFieldCount -gt 0) {
        for ($fieldCount = 0; $fieldCount -lt $dataFieldCount; $fieldCount++) {
            $dataRow = $shape.CellsSRC($visSectionProp, $fieldCount, $visCustPropsValue).name
            $name = $shape.Cells($dataRow).RowNameU
            $shape.Cells($dataRow).Formula = [string]('"' + ($taskData.$name -replace '"', '') + '"')
        }
    }

    # Recursively call data assignment function if there are any sub-shapes..
    $subShapeCount = $shape.Shapes.count
    if ($subShapeCount -ne 0) {
        for ($shapeNum = 1; $shapeNum -le $subShapeCount; $shapeNum++) {
            assignDataToShape $taskData $shape.Shapes.item($shapeNum)
        }
    }
}

#################################################################################################################################################################
# Initialization
#################################################################################################################################################################
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
cd $scriptPath

# Resolve relative paths and make sure files are there
$files.csvTaskDataFile = validateDatafileAvailability $csvTaskDataFile
$files.csvRelDataFile = validateDatafileAvailability $csvRelDataFile
$files.stencilFile = validateDatafileAvailability $stencilFile
$files.visioEnum = validateDatafileAvailability ".\data\visioEnum.ps1"

# Source visio enumerations
. $files.visioEnum

# 15 seconds of fame.
write-host "* AWA Visio(n), by Joel Wiesmann"
write-host ("** Stencil:   " + $files.stencilFile)
write-host ("** Task data: " + $files.csvTaskDataFile)
write-host ("** Rel data:  " + $files.csvRelDataFile)
write-host "** Delimiter: $delimiter"
write-host "** Output:    $outputFile"
write-host ("** Starttime: " + (get-date -Format "dd.MM.yyyy HH:mm:ss"))

# Load / verify the workflow data 
try {
    $data = gc $files.csvTaskDataFile
    $taskDataCSV = ConvertFrom-Csv $data -Delimiter $delimiter
    checkMandatoryField "x" $files.csvTaskDataFile $taskDataCSV[0]
    checkMandatoryField "y" $files.csvTaskDataFile $taskDataCSV[0]
    checkMandatoryField "lnr" $files.csvTaskDataFile $taskDataCSV[0]
    checkMandatoryField "type" $files.csvTaskDataFile $taskDataCSV[0]

    $data = gc $files.csvRelDataFile
    $relDataCSV = ConvertFrom-Csv $data -Delimiter $delimiter
    checkMandatoryField "lnr" $files.csvRelDataFile $relDataCSV[0]
    checkMandatoryField "prelnr" $files.csvRelDataFile $relDataCSV[0]
}
catch {
    write-host ("! Issues loading data (" + $_.Exception.Message + ").")
    exit 1
}

# Mirror the Y-axis in the task specification
$maxYvalue = ($taskDataCSV.GetEnumerator() | sort Y -Descending | Select-Object -First 1).Y
foreach ($task in $taskDataCSV) {
    $task.Y = ($task.Y - $maxYvalue) * -1
}

# Determine the requested output format
$outputFormat = ($outputFile -split "\.")[-1]

# If the task & relation files contain a field named "pagename", multiple workflows can be documented at once
$workflowList = @()
$taskMultiPage = [bool]($taskDataCSV[0].psobject.properties | where { $_.Name -eq "pagename" })
$relMultiPage  = [bool]($relDataCSV[0].psobject.properties | where { $_.Name -eq "pagename" })

# In case that the files have no pagename field, it will be artificially added
if ($taskMultiPage -and $relMultipage) {
    if ($outputFormat -ne "vsd") {
        write-host "! Multipage only supported with vsd output format."
        exit 1
    }

    $workflowList = @($taskDataCSV | % { $_.pagename } | Sort-Object -Unique)
}
else {
    $workflowList = @($pagename)
    foreach ($task in $taskDataCSV) { $task | Add-Member -MemberType NoteProperty -Name "pagename" -value $pageName }
    foreach ($rel in $relDataCSV) { $rel | Add-Member -MemberType NoteProperty -Name "pagename" -value $pageName }
}

if ($taskMultiPage -xor $relMultipage) {
    write-host "! Multipage is only supported if both files contain pagename CSV field."
    exit 1
}

# Initialize Visio
try {
    $application = New-Object -ComObject Visio.Application
    $application.visible = $visioVisible
    $documents = $application.Documents
}
catch {
    
    write-host "! Could not initialize Visio."
    exit 1
}

# If output format is vsd AND the output file is already existing, the documentation might be added to the existing tab or the existing page gets replaced.
if (($outputFormat -match "vsd") -and (get-childitem -erroraction SilentlyContinue $outputFile)) {
    try { $document = $documents.Open($outputfile) }
    catch {
        write-host "! Don't panic. The $outputfile is likely to be already opened. Please kill all open visio processes and try again."
        $application.quit()
        exit 1
    }
}
else {
    # Create new document but delete the empty default page. We can do this at the end.
    $document = $documents.Add("") 
    $removeFirst = $true
}

# Load the mastershapes from the stencil
$mastershapes = @{}
$objectStencil = $application.Documents.Add($files.stencilFile)
foreach ($stencil in $Objectstencil.Masters) {
    $mastershapes.($stencil.name) = $stencil
}

if (! $mastershapes."default") {
    write-host "! $files.stencilFile does not contain a 'default' mastershape."
}

if (! $mastershapes."connector") {
    write-host "! $files.stencilFile does not contain a 'connector' mastershape."
}

foreach ($workflow in $workflowList) {
    for ($pageNumber = 1; $pageNumber -le $document.Pages.count; $pageNumber++) {
        if ($document.pages.item($pageNumber).NameU -eq $workflow) {
            write-host "* Deleting already existing page with same pagename for recreation."
            $document.pages.item($pageNumber).delete(1)
        }
    }

    $pages = $application.ActiveDocument.Pages
    $page = $document.Pages.Add()
    $page.name = $workflow

    # Layout options making look the workflow like a workflow.
    $page.PageSheet.CellsSRC($visSectionObject, $visRowPageLayout, $visPLORouteStyle).FormulaForceU = "6"
    $page.PageSheet.CellsSRC($visSectionObject, $visRowPageLayout, $visPLOLineAdjustFrom).FormulaForceU = "1"
    $page.PageSheet.CellsSRC($visSectionObject, $visRowPageLayout, $visPLOLineAdjustTo).FormulaForceU = "2"
    $page.PageSheet.CellsSRC($visSectionObject, $visRowPageLayout, $visPLOLineRouteExt).FormulaForceU = "1"

    #################################################################################################################################################################
    # Drop shapes & assign value
    #################################################################################################################################################################
    $shapes = @{}
    write-host -NoNewline "* Drawing tasks"
    foreach ($task in $taskDataCSV) {
        if ($task.pageName -ne $workflow) { continue }
    
        write-host -NoNewline "."

        # Verify if stencil is known. If not, drop the unknown stencil.
        if (! $mastershapes.([String]$task.type)) {
            # Message is too chatty. 
            # write-host ("! No mastershape available for task type " + $task.type)
            $obj = $mastershapes."default"
        }
        else { $obj = $mastershapes.([String]$task.type) }

        # Drop stencil onto page, use the x/y coordinates we get from the export.
        $shapes.($task.lnr) = $page.Drop($obj, ([int]$task.x * $xSpacing), $task.y * $ySpacing)
        assignDataToShape $task $shapes.($task.lnr)
    }
    write-host

    write-host -NoNewline "* Drawing relations"
    # We do the same as above to the task relations. 
    foreach ($relation in $relDataCSV) {
        if ($relation.pageName -ne $workflow) { continue }
        
        write-host -NoNewline "."
        
        if (! $relation.type) {
            $relation | Add-Member -MemberType NoteProperty -Name "type" -value "connector"
        }

        if (! $mastershapes.($relation.type)) {
            # write-host ("! No stencil available for connector type " + $relation.type)
            $relation.type = "connector"
        }

        if (-not $relation.prelnr -or -not $relation.lnr) { continue }

        # AutoConnect won't return a shape so we set a unique name to find the connector
        $connectorShape = $mastershapes.($relation.type)
        $connectorName = ("con_" + $relation.lnr + ":" + $relation.prelnr)
        $connectorShape.nameU = $connectorName
        
        try { $shapes.($relation.lnr).AutoConnect($shapes.($relation.prelnr), 0, $connectorShape) }
        catch {
            write-host 
            write-host("! Linking lnr: " + $relation.lnr + " with prelnr: " + $relation.prelnr + " failed.") 
        }

        # Inactivated due to performance issues. Will be fixed somewhen.
        #   $page.shapes | where { $_.NameU -eq $connectorName } | % { $connectorShape = $_ }
        # Fill-in datafields of connector shape
        #    assignDataToShape $relation $connectorShape
    }
    write-host 

    $page.ResizeToFitContents()
}

if ($removeFirst) { $document.pages.item(1).delete(1) }

#################################################################################################################################################################
# Finalize / save & export
#################################################################################################################################################################
# VSDs support multiple pages in one file.
if ($outputFormat -match "vsd") {
    if (Get-ChildItem -ErrorAction SilentlyContinue $outputFile) {
        if ($document.save() -eq 0) { write-host "* Document successfully saved!" }
        else { write-host "! Ow! My brains! Saving failed!" }
    }
    else {
        if ($document.saveas($outputFile) -eq 0) { write-host "* Document successfully saved!" }
        else { write-host "! Time is not currently one of my problems. Saving failed!" }
    }
}
else {
    if ($page.export($outputFile) -ne 0) { write-host "* Page exported successfully" }
    else { write-host "! I could have more fun in cat litter. Exporting failed!" }
}

# Properly close Visio or there will be hanging processes.
$objectStencil.saved = $true
$document.saved = $true
$document.close()
$application.quit()

write-host ("** Endtime: " + (get-date -Format "dd.MM.yyyy HH:mm:ss"))
write-host
write-host "Goodbye and thanks for all the fish ><(((º>"