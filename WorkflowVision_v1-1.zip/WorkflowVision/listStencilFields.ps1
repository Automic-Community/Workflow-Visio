﻿# AWA Visio(n) - listStencilFields
# Lists available fields & description within stencil file.

# Code, stencils and basic SQLs by Joel Wiesmann / joel.wiesmann@gmail.com, June 2016
# Requires: Visio 2010 or 2016. Might work with earlier versions as well. Only professional has been tested.

#################################################################################################################################################################
# Parameters
#################################################################################################################################################################
# -stencilFile <stencil.vss>   -- Stencil file to process
#################################################################################################################################################################

Param(
    [Parameter(Mandatory=$True)][string]$stencilFile
)

#################################################################################################################################################################
# Functions
#################################################################################################################################################################
# Verify if all files are there and relative paths can be resolved properly. Register all files in the $files hash array.
function validateDatafileAvailability($file) {
    if (! ($resolvedPath = Resolve-Path($file))) {
        write-host ("! Could not resolve path to " + $file)
        exit 1
    }
    $resolvedPath
}

function listShapeFields($shape) {
    try { $dataFieldCount = $shape.rowcount(243) }
    catch { return }

    if ($dataFieldCount -gt 0) {
        for ($fieldCount = 0; $fieldCount -lt $dataFieldCount; $fieldCount++) {
            $dataRow = $shape.CellsSRC($visSectionProp, $fieldCount, $visCustPropsValue).name
            "*** {0,-20}: {1}" -f ($shape.Cells($dataRow).RowNameU), ($shape.Cells($dataRow + ".label").FormulaU)
        }
    }

    for ($shapeCount = 0; $shapeCount -le $shape.shapes.count; $shapeCount++) {
        try { listShapeFields $shape.shapes[$shapeCount] }
        catch { continue }
    }
}

#################################################################################################################################################################
# Initialization
#################################################################################################################################################################
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
cd $scriptPath

# Resolve relative paths and make sure files are there
$stencilFileAbs = validateDatafileAvailability $stencilFile
$visioEnum = validateDatafileAvailability ".\data\visioEnum.ps1"
. $visioEnum

# 15 seconds of fame.
write-host "* AWA Visio(n) - listStencilFields, by Joel Wiesmann"
write-host ("** Stencil:   " + $files.stencilFile)
write-host ("** Starttime: " + (get-date -Format "dd.MM.yyyy HH:mm:ss"))

# Initialize Visio
try {
    $application = New-Object -ComObject Visio.Application
    $application.visible = $False
    $documents = $application.Documents
}
catch {
    write-host "! Could not initialize Visio."
    exit 1
}

# Load the mastershapes from the stencil
$mastershapes = @{}
$objectStencil = $application.Documents.Add($stencilFileAbs)
foreach ($stencil in $Objectstencil.Masters) {
    write-host ("** Mastershape: " + $stencil.name) -ForegroundColor "yellow"

    for($shapeCount = 1; $shapeCount -le $stencil.shapes.Count; $shapeCount++) {
        $shape = $stencil.shapes[$shapeCount]
        listShapeFields $shape
    }
}

#$application.Documents.close()
$application.quit()

write-host ("** Endtime: " + (get-date -Format "dd.MM.yyyy HH:mm:ss"))
write-host
write-host "Goodbye and thanks for all the fish ><(((º>"