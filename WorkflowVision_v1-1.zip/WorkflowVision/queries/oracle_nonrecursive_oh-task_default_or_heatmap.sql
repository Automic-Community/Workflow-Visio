/*
* -- 1.0 initial version, Joel Wiesmann, joel.wiesmann@gmail.com
* Feedback is appreciated. Join Philipp Elmer's AE DB Workshop if you want to learn how to create such queries & more.
*
* Requires WORKFLOW and CLIENT as this goes on OH table. Heatmap logic uses minimum/maximum task runtime for 0/100. See end of SQL.
*/
alter session set current_schema = uc4; 

with tasks as ( 
  select
    JPP_Lnr as Lnr,
    JPP_Object as objectName,
    coalesce(JPP_Alias, JPP_Object) as Name,
    JPP_OType as Type,
    JPP_Row as Y,
    JPP_Col as X,
    JPP_Active as Active
  from jpp
  join OH on JPP_OH_Idnr = OH_Idnr
  where OH_Client = :CLIENT
  and OH_Name = :WORKFLOW
  and OH_Deleteflag = 0
),
tasksErt as (
  select 
    tasks.*, 
    OH_Title as Description,
    OH_Ert as Ert,
    CASE 
      -- You can add the LoginDst / LoginSrc as well
      WHEN OH_OTYPE = 'JOBS' THEN (select JBA_HostDst from JBA where JBA_OH_Idnr = OH_idnr)
      WHEN OH_OTYPE = 'JOBF' THEN (select JFA_HostSrc || '=>' || JFA_HostDst from JFA where JFA_OH_Idnr = OH_idnr)
  -- EVNT is missing here
      ELSE 'n/a'
    END
    as Agent
  from tasks
  left join OH on OH_Name = tasks.objectName 
  and OH_Client = :CLIENT
  and OH_Deleteflag = 0
)
select 
  tasksErt.*,
  CASE WHEN ERT IS NOT NULL THEN TO_CHAR(TRUNC(ert/3600),'FM9900') || ':' || TO_CHAR(TRUNC(MOD(ert,3600)/60),'FM00') || ':' || TO_CHAR(MOD(ert,60),'FM00') END as heatData,
  -- Method 1
  round((ert - (select min(Ert) from tasksErt)) / (select max(Ert) from tasksErt) * 100, 0) as heat
  -- Method 2
  -- CASE 
  --    WHEN Ert < 300 THEN 0
  --    WHEN Ert < 900 THEN 25
  --    WHEN Ert < 1800 THEN 50
  --    WHEN Ert < 3600 THEN 75
  --	  ELSE 100
  -- END as heat
from tasksErt
