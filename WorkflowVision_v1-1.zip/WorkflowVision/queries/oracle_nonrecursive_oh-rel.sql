/*
* -- 1.0 initial version, Joel Wiesmann, joel.wiesmann@gmail.com
* Feedback is appreciated. Join Philipp Elmer's AE DB Workshop if you want to learn how to create such queries & more.
*
* Requires WORKFLOW and CLIENT. Goes on OH table.
*/
alter session set current_schema = uc4; 

select
  JPPA_JPP_Lnr as Lnr,
  JPPA_PreLnr as PreLnr
from JPPA
join OH on OH_Idnr = JPPA_OH_Idnr
where OH_Name = :WORKFLOW
and OH_Client = :CLIENT
and OH_DeleteFlag = 0;