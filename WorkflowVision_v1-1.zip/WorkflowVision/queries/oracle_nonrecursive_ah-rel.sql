/*
* -- 1.0 initial version, Joel Wiesmann, joel.wiesmann@gmail.com
* Feedback is appreciated. Join Philipp Elmer's AE DB Workshop if you want to learn how to create such queries & more.
*
* Requires runid as this goes on archive table. Default heatmap logic is based on absolute time (<5 min 0, <15 min 25, <30 min 50, <60 min 75 else 100).
*/
alter session set current_schema = uc4; 

select 
  AJPPA_AJPP_LNR as lnr,
  AJPPA_PRELNR as prelnr
from AJPPA
where AJPPA_AH_IDNR = :runid