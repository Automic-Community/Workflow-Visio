/*
* -- 1.0 initial version, Joel Wiesmann, joel.wiesmann@gmail.com
* Feedback is appreciated. Join Philipp Elmer's AE DB Workshop if you want to learn how to create such queries & more.
*
* Requires runid as this goes on AH table. Default heatmap logic is based on absolute time (<5 min 0, <15 min 25, <30 min 50, <60 min 75 else 100).
*
*/

alter session set current_schema = uc4; 

with tasks(pagename, Lnr, Y, X, Active, Runid, name, type, description, heatdata, Runtime, Agent) as (
	select 
    (select AH_Name from AH where AH_Idnr = AJPP_AH_IDNR) as pagename,
	  AJPP_Lnr,
	  AJPP_Row,
	  AJPP_Col,
	  CASE WHEN AH_Status IS NULL THEN 0 ELSE 1 END,
    CASE WHEN AJPP_Otype != '<XTRNL>' THEN AJPP_TaskIdnr END,
	  coalesce(AJPP_Alias, AJPP_Object),
	  AJPP_Otype,
    CASE WHEN AH_Title IS NULL THEN 
        (select OH_Title from OH where OH_Client = AH_client and OH_Name = AJPP_Object and OH_Deleteflag = 0)
      ELSE 
        AH_Title 
    END, -- this is formally not correct but usually what viewers expect to see as inactive tasks get no AH_Title entry even if the task's object does exist.
    CASE WHEN AH_Runtime IS NOT NULL THEN 
      TO_CHAR(TRUNC(AH_Runtime/3600),'FM9900') || ':' || TO_CHAR(TRUNC(MOD(AH_Runtime,3600)/60),'FM00') || ':' || TO_CHAR(MOD(AH_Runtime,60),'FM00')
    END,
    AH_Runtime,
	  CASE 
	    -- You can add the LoginDst / LoginSrc as well
	    WHEN AJPP_Otype = 'JOBS' THEN (select AH_HostDst from AH where x.AH_Idnr = AH_idnr)
	    WHEN AJPP_Otype = 'JOBF' THEN (select AH_HostSrc || '=>' || AH_HostDst from AH where x.AH_Idnr = AH_idnr)
	    -- EVNT is missing here
	    ELSE 'n/a'
	  END
	from AJPP
	left join AH x on AH_Idnr = AJPP_Taskidnr
	where AJPP_AH_IDNR = :runid
union all
	select 
    (select AH_Name from AH where AH_Idnr = AJPP_AH_IDNR) as pagename,
	  AJPP_Lnr,
	  AJPP_Row,
	  AJPP_Col,
	  CASE WHEN childAH.AH_Status IS NULL THEN 0 ELSE 1 END,
    CASE WHEN AJPP_Otype != '<XTRNL>' THEN AJPP_TaskIdnr END,
	  coalesce(AJPP_Alias, AJPP_Object),
	  AJPP_OType,
    CASE WHEN childAH.AH_Title IS NULL THEN 
        (select OH_Title from OH where OH_Client = parentAH.AH_client and OH_Name = AJPP_Object and OH_Deleteflag = 0)
      ELSE 
        childAH.AH_Title 
    END, -- this is formally not correct but usually what viewers expect to see as inactive tasks get no AH_Title entry even if the task's object does exist.
    CASE WHEN childAH.AH_Runtime IS NOT NULL THEN 
      TO_CHAR(TRUNC(childAH.AH_Runtime/3600),'FM9900') || ':' || TO_CHAR(TRUNC(MOD(childAH.AH_Runtime,3600)/60),'FM00') || ':' || TO_CHAR(MOD(childAH.AH_Runtime,60),'FM00')
    END,
    childAH.AH_Runtime,
	  CASE 
	    -- You can add the LoginDst / LoginSrc as well
	    WHEN AJPP_Otype = 'JOBS' THEN (select AH_HostDst from AH where childAH.AH_Idnr = AH_idnr)
	    WHEN AJPP_Otype = 'JOBF' THEN (select AH_HostSrc || '=>' || AH_HostDst from AH where childAH.AH_Idnr = AH_idnr)
	    -- EVNT is missing here
	    ELSE 'n/a'
	  END as Agent
	from tasks
  join AJPP on tasks.runid = AJPP_AH_IDNR
  join AH parentAH on tasks.runid = parentAH.AH_IDNR
  left join AH childAH on AJPP_Taskidnr = childAH.AH_Idnr
)
select 
  tasks.*, 
  CASE WHEN type = 'JOBP' THEN Name END as Link,
  -- Method 1 buggy
 -- round((Runtime - (select min(Runtime) from tasks where type != '<XTRNL>')) / (select max(Runtime) from tasks where type != '<XTRNL>') * 100, 0) as heat
  -- Method 2
  CASE 
      WHEN Runtime < 300 THEN 0
      WHEN Runtime < 900 THEN 25
      WHEN Runtime < 1800 THEN 50
      WHEN Runtime < 3600 THEN 75
  	  ELSE 100
   END as heat
from tasks
