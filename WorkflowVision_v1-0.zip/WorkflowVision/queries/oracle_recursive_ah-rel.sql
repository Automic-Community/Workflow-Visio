/*
* -- 1.0 initial version, Joel Wiesmann, joel.wiesmann@gmail.com
*
* Feedback is appreciated. Join Philipp Elmer's AE DB Workshop if you want to learn how to create such queries & more.
*
* Query required runid as it's going on the archive tables.
*
*/
alter session set current_schema = uc4; 

with relations(pagename, runid, lnr, prelnr) as (
  select 
    (select AH_Name from AH where AH_IDNR = AJPPA_AH_IDNR),
    AJPP_Taskidnr,
    AJPPA_AJPP_LNR,
    AJPPA_PRELNR
  from AJPPA
  join AJPP on AJPP_AH_IDNR = AJPPA_AH_IDNR and AJPP_LNR = AJPPA_AJPP_LNR
  where AJPPA_AH_IDNR = :runid
union all
  select 
    (select AH_Name from AH where AH_IDNR = AJPPA_AH_IDNR),
    AJPP_Taskidnr,
    AJPPA_AJPP_LNR,
    AJPPA_PRELNR
  from relations
  join AJPP on AJPP_AH_Idnr = runid 
  join AJPPA on AJPPA_AH_Idnr = runid and AJPPA_AJPP_Lnr = AJPP_Lnr
)
select pagename, lnr, prelnr
from relations
