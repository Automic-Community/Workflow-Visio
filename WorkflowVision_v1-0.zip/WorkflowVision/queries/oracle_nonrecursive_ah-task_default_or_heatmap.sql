/*
* -- 1.0 initial version, Joel Wiesmann, joel.wiesmann@gmail.com
* Feedback is appreciated. Join Philipp Elmer's AE DB Workshop if you want to learn how to create such queries & more.
*
* Requires runid & client as this goes on AH table. Default heatmap logic is based on min & max running task duration (see end of SQL).
*/
alter session set current_schema = uc4; 

with tasks as (
	select 
	  AJPP_Lnr as Lnr,
	  AJPP_Row as Y,
	  AJPP_Col as X,
    CASE WHEN AH_Status IS NULL THEN 0 ELSE 1 END as Active,
	  coalesce(AJPP_Alias, AJPP_Object) as name,
	  AJPP_Otype as type,
    CASE WHEN AH_Title IS NULL THEN 
        (select OH_Title from OH where OH_Client = :client and OH_Name = AJPP_Object and OH_Deleteflag = 0)
      ELSE 
        AH_Title 
    END as description, -- this is formally not correct but usually what viewers expect to see as inactive tasks get no AH_Title entry even if the task's object does exist.
    CASE WHEN AH_Runtime IS NOT NULL THEN 
      TO_CHAR(TRUNC(AH_Runtime/3600),'FM9900') || ':' || TO_CHAR(TRUNC(MOD(AH_Runtime,3600)/60),'FM00') || ':' || TO_CHAR(MOD(AH_Runtime,60),'FM00')
    END as heatData,
    AH_Runtime,
	  CASE 
	    -- You can add the LoginDst / LoginSrc as well
	    WHEN AJPP_Otype = 'JOBS' THEN (select AH_HostDst from AH where x.AH_Idnr = AH_idnr)
	    WHEN AJPP_Otype = 'JOBF' THEN (select AH_HostSrc || '=>' || AH_HostDst from AH where x.AH_Idnr = AH_idnr)
	    -- EVNT is missing here
	    ELSE 'n/a'
	  END as Agent
	from AJPP
	left join AH x on AH_Idnr = AJPP_Taskidnr
	where AJPP_AH_IDNR = :runid
)
select 
  tasks.*, 
  -- Method 1
  round((AH_Runtime - (select min(AH_Runtime) from tasks where type != '<XTRNL>')) / (select max(AH_Runtime) from tasks where type != '<XTRNL>') * 100, 0) as heat
  -- Method 2
  -- CASE 
  --    WHEN AH_Runtime < 300 THEN 0
  --    WHEN AH_Runtime < 900 THEN 25
  --    WHEN AH_Runtime < 1800 THEN 50
  --    WHEN AH_Runtime < 3600 THEN 75
  --	  ELSE 100
  -- END as heat
from tasks